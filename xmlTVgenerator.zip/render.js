const { ipcRenderer } = require("electron");

const editor = document.getElementById("editor");
const openBtn = document.getElementById("openBtn");
const saveBtn = document.getElementById("saveBtn");

openBtn.addEventListener("click", () => {
  ipcRenderer.send("open-file-dialog");
});

saveBtn.addEventListener("click", () => {
  const content = editor.value;
  ipcRenderer.send("save-file-dialog", content);
});
ipcRenderer.on("open-file", (event, filePath, fileContent) => {
  editor.value = fileContent;

});

const boldBtn = document.getElementById('bold-btn');
boldBtn.addEventListener('click', () => {
  const start = editor.selectionStart;
  const end = editor.selectionEnd;
  const selectedText = editor.value.substring(start, end);
  const boldText = `<b>${selectedText}</b>`;
  const newText = editor.value.substring(0, start) + boldText + editor.value.substring(end);
  editor.value = newText;
});

editor.addEventListener('input', () => {
    const code = editor.value;
    //const highlightedCode = Prism.highlight(code, Prism.languages.javascript, 'javascript');
   // editor.innerHTML = highlightedCode;
  });


export default {
    methods: {
        save: function () {
            var options = {
                title: "Save file",
                defaultPath : "my_filename",
                buttonLabel : "Save",

                filters :[
                    {name: 'txt', extensions: ['txt']},
                    {name: 'All Files', extensions: ['*']}
                ]
            };

            dialog.showSaveDialog(null, options).then(({ filePath }) => {
                fs.writeFileSync(filePath, "hello world", 'utf-8');
            });
        },
    }
}
